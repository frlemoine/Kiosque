define( function ( require ) {

	"use strict";

	return {
		app_slug : 'actualites-en-droit-administratif',
		wp_ws_url : 'https://www.fleditionsnumeriques.fr/actualitesendroitadministratif/wp-appkit-api/actualites-en-droit-administratif',
		wp_url : 'https://www.fleditionsnumeriques.fr/actualitesendroitadministratif',
		theme : 'q-android',
		version : '1',
		app_type : 'phonegap-build',
		app_title : 'Actualités en Droit administratif',
		app_platform : 'android',
		app_path: '',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : '7Hg^i`k;~ic_{Ge8(kCZEw~)G}3j-[F~)>{wB_q]l86A[%i,)[z sX{7!pLq:gn*',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
